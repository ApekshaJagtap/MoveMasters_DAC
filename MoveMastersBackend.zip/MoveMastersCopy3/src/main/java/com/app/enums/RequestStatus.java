package com.app.enums;

public enum RequestStatus {
	VISITED,
    NOTVISITED

}
