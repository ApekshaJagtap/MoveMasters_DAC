package com.app.enums;

public enum VehicleType {
	BIKE,TAMPO,TRUCK

}
