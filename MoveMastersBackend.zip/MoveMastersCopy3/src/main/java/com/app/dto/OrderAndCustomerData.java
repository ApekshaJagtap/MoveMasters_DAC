package com.app.dto;

public class OrderAndCustomerData {
    private OrderDto orderData;
    private CustomerDto customerInfo;

}

